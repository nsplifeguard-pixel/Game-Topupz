# GAME TOPUP — Price Checker

เว็บแอปสำหรับ **ค้นหาและเช็คราคาเกม/สินค้าดิจิทัลเท่านั้น** โดยดึง catalog จาก Over Topup มาคำนวณราคาขายตาม margin และแสดงข้อมูลให้ตรวจสอบง่าย ระบบนี้ **ไม่มีการเติมเกม ไม่มีตะกร้า ไม่มี Checkout ไม่มี Order และไม่มีการชำระเงิน**

## Run locally

```bash
pnpm install
pnpm check
pnpm dev
```

เซิร์ฟเวอร์ใช้ `PORT` (default `3000`) และ bind ที่ `0.0.0.0` ตาม WebDev runtime

## Database

- `DATABASE_URL` ใช้ managed MySQL ของโปรเจกต์
- `pnpm db:push` ใช้ generate + migrate ผ่าน Drizzle เมื่อทำงานใน environment ที่มี credentials
- runtime เรียก `ensureSchema()` แบบ idempotent เพื่อรองรับการ bootstrap/published instance
- catalog หลักอยู่ที่ `drizzle/schema.ts` และ migration ใน `drizzle/`

## Admin

- route: `/admin/login`
- username เริ่มต้น: `admin`
- initial password มาจาก secret `INITIAL_ADMIN_PASSWORD` เท่านั้น ไม่เก็บใน source และ login ครั้งแรกบังคับเปลี่ยนรหัสผ่าน
- Admin ใช้จัดการ catalog, margin, ราคา, price history, Sync และ settings ของ price checker
- session token ถูก hash ใน `admin_sessions`; password ใช้ Node `crypto.scrypt`; mutation ที่ใช้ cookie session ตรวจ CSRF

## Sync และราคา

- source URL default: `https://www.overtopup.com/th`
- crawler ค้นพบ category/game/product จาก internal links แบบ dynamic, normalize URL และ parse metadata/DOM fallback
- `POST /api/admin/sync` เริ่ม sync; `GET /api/admin/sync-status` ดู progress/logs
- `POST /api/scheduled/sync` เตรียมไว้สำหรับ scheduled callback หลัง publish
- default margin `20%`; selling price คำนวณ server-side และ source price ส่งเฉพาะ Admin endpoints
- price history บันทึกเมื่อ source หรือ selling price เปลี่ยน; สินค้าที่หายจาก source เปลี่ยนเป็น `OUT_OF_STOCK` โดยไม่ลบ
- Public API แสดงเฉพาะชื่อสินค้า รายละเอียด รูป เกม ประเภท และราคาขาย ไม่แสดงต้นทุนหรือข้อมูล Admin

## Image / content rights

ระบบใช้รูปภาพและข้อมูลสินค้าจาก URL สาธารณะต้นทางเพื่อการแสดงราคาเท่านั้น ควรตรวจสอบ ToS, robots, ลิขสิทธิ์ และสิทธิ์การใช้รูปภาพก่อนเปิดให้บริการเชิงพาณิชย์จริง หากต้นทางไม่พร้อมใช้งาน ระบบคงข้อมูลล่าสุดและแสดง fallback แทนการลบข้อมูล

## Routes

- Price checker: `/`, `/games`, `/games/:slug`
- Admin: `/admin/login`, `/admin`, `/admin/games`, `/admin/products`, `/admin/pricing`, `/admin/sync`, `/admin/price-history`, `/admin/settings`, `/admin/account`
- Route manifest: `client/public/manus-routes.json`
