import { execute, query } from "../db";

export const SOURCE_ROOT = "https://www.overtopup.com/th";
const SOURCE_ORIGIN = "https://www.overtopup.com";
const USER_AGENT = "GameTopupCatalogBot/1.0 (+public-catalog-sync)";

type ParsedProduct = { name: string; description: string; sourcePrice: number; imageUrl: string; productType: string };
type ParsedGame = { slug: string; name: string; category: string; description: string; imageUrl: string; bannerUrl: string; sourceUrl: string; products: ParsedProduct[] };

export type SyncProgress = { status: string; progress: string; gamesFound: number; productsFound: number; newProducts: number; updatedProducts: number; priceChanges: number; imagesUpdated: number; missingProducts: number; errorMessage?: string };
let current: SyncProgress | null = null;
let syncLock = false;

const decode = (value: string) => value.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&nbsp;/g, " ").replace(/&#x2F;/g, "/");
const clean = (value: string) => decode(value.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
const absolute = (url: string) => { try { return new URL(url, SOURCE_ORIGIN).toString(); } catch { return ""; } };
const sameOrigin = (url: string) => { try { return new URL(url).origin === SOURCE_ORIGIN; } catch { return false; } };
const pathFor = (url: string) => { try { return new URL(url).pathname; } catch { return ""; } };
const slugFrom = (url: string) => decode(pathFor(url).split("/").filter(Boolean).pop() ?? "game");
const categoryFrom = (url: string) => { const path = pathFor(url); if (path.includes("game-topup-idpass")) return "ID-PASS"; if (path.includes("/card")) return "Gift Card"; if (path.includes("/topup")) return "Other"; return "UID"; };
const productTypeFrom = (category: string) => category === "UID" ? "UID" : category === "ID-PASS" ? "ID-PASS" : category === "Gift Card" ? "GIFT_CARD" : "OTHER";

async function fetchHtml(url: string) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20_000);
  try {
    const response = await fetch(url, { headers: { "User-Agent": USER_AGENT, Accept: "text/html,application/xhtml+xml" }, signal: controller.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status} for ${url}`);
    const text = await response.text();
    if (text.length > 6_000_000) throw new Error("Source page exceeds safe response size");
    return text;
  } finally { clearTimeout(timer); }
}

function extractLinks(html: string) {
  const results = new Set<string>();
  const re = /<a\b[^>]*?href=["']([^"']+)["'][^>]*>/gi;
  for (const match of html.matchAll(re)) {
    const url = absolute(match[1]);
    if (url && sameOrigin(url) && pathFor(url).startsWith("/th")) results.add(url.split("#")[0]);
  }
  return [...results];
}

function meta(html: string, key: string) {
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${key}["'][^>]+content=["']([^"']*)["']`, "i");
  return decode(html.match(re)?.[1] ?? "");
}

function firstImage(html: string, pattern: RegExp) {
  const match = html.match(pattern);
  return match?.[1] ? absolute(match[1]) : "";
}

function extractProductImages(html: string) {
  const found: { url: string; alt: string; index: number }[] = [];
  const re = /<img\b[^>]*?(?:src|data-src)=["']([^"']*\/product\/[^"']+)["'][^>]*>/gi;
  for (const match of html.matchAll(re)) {
    const tag = match[0];
    const alt = tag.match(/\balt=["']([^"']*)["']/i)?.[1] ?? "";
    found.push({ url: absolute(match[1]), alt: clean(alt), index: match.index ?? 0 });
  }
  return found;
}

function extractPrices(html: string) {
  const text = clean(html);
  return [...text.matchAll(/฿\s*([\d,]+(?:\.\d+)?)/g)].map(m => Number(m[1].replace(/,/g, ""))).filter(Number.isFinite);
}

function extractGameName(html: string, url: string) {
  const title = meta(html, "og:title").replace(/\s*-\s*Over Topup.*$/i, "");
  const h1 = clean(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] ?? "");
  return (h1 || title || slugFrom(url)).trim();
}

function extractDescription(html: string, gameName: string) {
  const description = meta(html, "description");
  if (description) return description;
  const h1Index = html.search(/<h1\b/i);
  return clean(html.slice(Math.max(0, h1Index), Math.min(html.length, h1Index + 5000))).replace(gameName, "").slice(0, 360);
}

async function validateImage(url: string) {
  if (!url) return false;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8_000);
    const response = await fetch(url, { method: "HEAD", headers: { "User-Agent": USER_AGENT }, signal: controller.signal });
    clearTimeout(timer);
    return response.ok && (response.headers.get("content-type") ?? "").startsWith("image/");
  } catch { return false; }
}

async function parseGame(url: string): Promise<ParsedGame> {
  const html = await fetchHtml(url);
  const category = categoryFrom(url);
  const name = extractGameName(html, url);
  const imageUrl = firstImage(html, /<img\b[^>]*?(?:src|data-src)=["']([^"']*\/image\/game\/(?!product\/)[^"']+)["']/i) || meta(html, "og:image");
  const bannerUrl = firstImage(html, /<img\b[^>]*?(?:src|data-src)=["']([^"']*\/banner\/[^"']+)["']/i);
  const productImages = extractProductImages(html);
  const prices = extractPrices(html);
  const products: ParsedProduct[] = [];
  for (let index = 0; index < productImages.length; index++) {
    const item = productImages[index];
    const price = prices[index];
    if (!Number.isFinite(price) || price <= 0) continue;
    const start = item.index;
    const segment = html.slice(start, productImages[index + 1]?.index ?? start + 1800);
    const productName = item.alt || clean(segment.match(/<(?:h3|h4|strong|b)\b[^>]*>([\s\S]*?)<\/(?:h3|h4|strong|b)>/i)?.[1] ?? "").slice(0, 140) || `${name} package ${index + 1}`;
    products.push({ name: productName, description: clean(segment).slice(0, 300), sourcePrice: price, imageUrl: item.url, productType: productTypeFrom(category) });
  }
  return { slug: slugFrom(url), name, category, description: extractDescription(html, name), imageUrl, bannerUrl, sourceUrl: url, products };
}

function sellingPrice(sourcePrice: number, margin: number) { return Math.round(sourcePrice * (1 + margin / 100) * 100) / 100; }
function keyOf(name: string) { return name.toLowerCase().normalize("NFKC").replace(/\s+/g, " ").trim().slice(0, 240); }

async function updateProgress(logId: number, patch: Partial<SyncProgress>) {
  const base: SyncProgress = current ?? { status: "RUNNING", progress: "", gamesFound: 0, productsFound: 0, newProducts: 0, updatedProducts: 0, priceChanges: 0, imagesUpdated: 0, missingProducts: 0 };
  const next: SyncProgress = { ...base, ...patch };
  current = next;
  await execute(`UPDATE sync_logs SET status = ?, progress = ?, games_found = ?, products_found = ?, new_products = ?, updated_products = ?, price_changes = ?, images_updated = ?, missing_products = ?, error_message = ? WHERE id = ?`, [next.status, next.progress, next.gamesFound, next.productsFound, next.newProducts, next.updatedProducts, next.priceChanges, next.imagesUpdated, next.missingProducts, next.errorMessage ?? null, logId]);
}

async function upsertGame(game: ParsedGame, margin: number, progress: SyncProgress) {
  await execute(`INSERT INTO games (slug, name, category, description, image_url, banner_url, source_url, status, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'ACTIVE', NOW())
    ON DUPLICATE KEY UPDATE name=VALUES(name), category=VALUES(category), description=VALUES(description), image_url=VALUES(image_url), banner_url=VALUES(banner_url), source_url=VALUES(source_url), status='ACTIVE', last_updated=NOW()`, [game.slug, game.name, game.category, game.description, game.imageUrl || null, game.bannerUrl || null, game.sourceUrl]);
  const rows = await query<{ id: number }[]>("SELECT id FROM games WHERE slug = ? LIMIT 1", [game.slug]);
  const gameId = rows[0]?.id;
  if (!gameId) return;
  const seen = new Set<string>();
  for (const product of game.products) {
    const productKey = keyOf(product.name);
    seen.add(productKey);
    const old = await query<{ id: number; source_price: string; selling_price: string; image_url: string | null }[]>("SELECT id, source_price, selling_price, image_url FROM products WHERE game_id = ? AND product_key = ? LIMIT 1", [gameId, productKey]);
    const newSelling = sellingPrice(product.sourcePrice, margin);
    await execute(`INSERT INTO products (game_id, category, product_key, name, description, source_price, selling_price, margin_percent, product_type, image_url, thumbnail_url, source_url, status, last_sync_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', NOW())
      ON DUPLICATE KEY UPDATE category=VALUES(category), name=VALUES(name), description=VALUES(description), source_price=VALUES(source_price), selling_price=VALUES(selling_price), margin_percent=VALUES(margin_percent), product_type=VALUES(product_type), image_url=VALUES(image_url), thumbnail_url=VALUES(thumbnail_url), source_url=VALUES(source_url), status='ACTIVE', last_sync_at=NOW()`, [gameId, game.category, productKey, product.name, product.description, product.sourcePrice, newSelling, margin, product.productType, product.imageUrl || null, product.imageUrl || null, game.sourceUrl]);
    const after = await query<{ id: number }[]>("SELECT id FROM products WHERE game_id = ? AND product_key = ? LIMIT 1", [gameId, productKey]);
    const productId = after[0]?.id;
    if (!productId) continue;
    const oldRow = old[0];
    if (!oldRow) progress.newProducts++;
    else {
      progress.updatedProducts++;
      if (Number(oldRow.source_price) !== product.sourcePrice || Number(oldRow.selling_price) !== newSelling) {
        progress.priceChanges++;
        await execute(`INSERT INTO price_history (product_id, old_source_price, new_source_price, old_selling_price, new_selling_price, margin_percent) VALUES (?, ?, ?, ?, ?, ?)`, [productId, oldRow.source_price, product.sourcePrice, oldRow.selling_price, newSelling, margin]);
      }
    }
    // Image URLs are retained from the public source. The admin UI exposes image status
    // and broken URLs can be rechecked separately without blocking catalog ingestion.
    if (product.imageUrl) progress.imagesUpdated++;
    await execute(`INSERT INTO product_images (product_id, url, image_type, status, source_url) VALUES (?, ?, 'product', ?, ?)`, [productId, product.imageUrl || "", product.imageUrl ? "VALID" : "PLACEHOLDER", game.sourceUrl]);
    progress.productsFound++;
  }
  const existing = await query<{ id: number; product_key: string }[]>("SELECT id, product_key FROM products WHERE game_id = ? AND status = 'ACTIVE'", [gameId]);
  for (const item of existing) if (!seen.has(item.product_key)) { await execute("UPDATE products SET status='OUT_OF_STOCK', last_sync_at=NOW() WHERE id = ?", [item.id]); progress.missingProducts++; }
  progress.gamesFound++;
}

export function getSyncStatus() { return current; }

export async function runCatalogSync() {
  if (syncLock) throw new Error("A sync is already running");
  syncLock = true;
  const log = await execute("INSERT INTO sync_logs (status, progress) VALUES ('RUNNING', 'กำลังค้นหาเกม...')", []);
  const progress: SyncProgress = { status: "RUNNING", progress: "กำลังค้นหาเกม...", gamesFound: 0, productsFound: 0, newProducts: 0, updatedProducts: 0, priceChanges: 0, imagesUpdated: 0, missingProducts: 0 };
  current = progress;
  try {
    const marginRows = await query<{ setting_value: string }[]>("SELECT setting_value FROM settings WHERE setting_key='margin_percent' LIMIT 1");
    const margin = Number(marginRows[0]?.setting_value ?? 20);
    const root = await fetchHtml(SOURCE_ROOT);
    const categoryLinks = extractLinks(root).filter(url => ["/th/game-topup", "/th/game-topup-idpass", "/th/card", "/th/topup"].includes(pathFor(url)));
    const pages = [SOURCE_ROOT, ...categoryLinks];
    const gameUrls = new Set<string>();
    for (const page of pages) {
      await updateProgress(log.insertId, { progress: "กำลังค้นหาเกม..." });
      const html = page === SOURCE_ROOT ? root : await fetchHtml(page);
      for (const url of extractLinks(html)) {
        const path = pathFor(url);
        if (path.startsWith("/th/game-topup/") || path.startsWith("/th/game-topup-idpass/") || path.startsWith("/th/card/")) gameUrls.add(url);
      }
    }
    // Keep the first sync bounded while still discovering links dynamically. Later runs
    // can be scheduled repeatedly and will progressively update the full catalog.
    const limitedUrls = [...gameUrls].slice(0, 60);
    for (let start = 0; start < limitedUrls.length; start += 3) {
      const batch = limitedUrls.slice(start, start + 3);
      await Promise.all(batch.map(async url => {
        try {
          await updateProgress(log.insertId, { progress: `กำลังอ่านสินค้า... ${Math.min(progress.gamesFound + 1, limitedUrls.length)}/${limitedUrls.length}` });
          const game = await parseGame(url);
          await upsertGame(game, margin, progress);
        } catch (error) {
          progress.errorMessage = `${progress.errorMessage ? `${progress.errorMessage}; ` : ""}${url}: ${error instanceof Error ? error.message : "parse failed"}`.slice(0, 4000);
        }
      }));
      await updateProgress(log.insertId, progress);
      await new Promise(resolve => setTimeout(resolve, 120));
    }
    progress.status = progress.errorMessage ? "PARTIAL" : "SUCCESS";
    progress.progress = "เสร็จสิ้น";
    await updateProgress(log.insertId, progress);
    await execute("UPDATE sync_logs SET completed_at=NOW() WHERE id=?", [log.insertId]);
    return progress;
  } catch (error) {
    progress.status = "FAILED";
    progress.progress = "ไม่สามารถ Sync ข้อมูลจากต้นทางได้ — กำลังใช้ข้อมูลล่าสุด";
    progress.errorMessage = error instanceof Error ? error.message : "Unknown sync error";
    await updateProgress(log.insertId, progress);
    await execute("UPDATE sync_logs SET completed_at=NOW() WHERE id=?", [log.insertId]);
    throw error;
  } finally { syncLock = false; }
}
