import { execute, query } from "./db";
import { hashPassword } from "./auth";

export async function seedApplication() {
  const existing = await query<{ id: number }[]>("SELECT id FROM admins WHERE username = 'admin' LIMIT 1");
  if (!existing.length && process.env.INITIAL_ADMIN_PASSWORD) {
    const { hash, salt } = hashPassword(process.env.INITIAL_ADMIN_PASSWORD);
    await execute(`INSERT INTO admins (username, password_hash, password_salt, must_change_password, is_active)
      VALUES ('admin', ?, ?, 1, 1)`, [hash, salt]);
  }
  await execute(`INSERT IGNORE INTO settings (setting_key, setting_value) VALUES
    ('margin_percent','20'), ('rounding_mode','nearest'), ('currency','THB'), ('timezone','Asia/Bangkok'),
    ('store_name','Game Topup'), ('tagline','เช็คราคาเกมและสินค้าดิจิทัล'), ('source_url','https://www.overtopup.com/th'), ('maintenance_mode','0')`);
}
