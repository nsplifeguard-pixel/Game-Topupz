# แผนพัฒนา Game Topup Price Checker

## เป้าหมาย
พัฒนา Game Topup ให้เป็นเว็บสำหรับค้นหาและเช็คราคาเกม/สินค้าดิจิทัลเท่านั้น โดยดึงข้อมูลสาธารณะจาก Over Topup, คำนวณ selling price จากต้นทุน + margin 20%, แสดง catalog ที่ค้นหา/กรอง/เรียงได้ และมี Admin สำหรับดูแลราคาและ Sync

> **ข้อจำกัดสำคัญ:** ระบบไม่มีการเติมเกม ไม่มีตะกร้า ไม่มี Checkout ไม่มี Order ไม่มี customer checkout และไม่มี payment provider

## Design
ใช้ Dark Gaming × Premium × Futuristic × Neon Blue ตามโลโก้ที่ผู้ใช้ให้มา: deep navy `#050B18`, `#071225`, `#0B1630`, Electric Blue/Cyan/White, sticky glassmorphism header, neon glow และ responsive layout

Brand voice สั้น ชัด และไม่สื่อว่าร้านรับเติมเกม: “เช็คราคาเกมและสินค้าดิจิทัล”, “ดูราคาอัปเดตจากต้นทางในที่เดียว”, “ข้อมูลราคาเท่านั้น ไม่มีการชำระเงิน” โลโก้เดิมใช้ใน header, hero, footer, favicon, loading, admin login และ error/fallback โดยไม่บิดสัดส่วน

## โครงสร้างหลัก

- `client/src/App.tsx` — Home, catalog search, game detail, price detail modal และ Admin UI
- `client/public/manus-routes.json` — เฉพาะ route price checker และ Admin
- `server/appRoutes.ts` — public catalog/search, Admin auth, pricing, Sync, history, settings และ scheduled Sync; ไม่มี order/customer endpoints
- `server/crawler/` — dynamic discovery/parser/upsert จาก source
- `server/db.ts`, `drizzle/schema.ts`, `drizzle/*.sql` — managed MySQL, catalog, prices, history, sync, settings และ auth
- `server/auth.ts`, `server/seed.ts` — password/session/admin bootstrap

## Required behavior

1. Public pages `/`, `/games`, `/games/:slug` ใช้ข้อมูล DB จริง มีค้นหา กรองประเภท เรียงราคา pagination/limit, game cards, product cards, placeholder, loading, empty และ error state
2. Product card และ modal แสดงเฉพาะ selling price; ปุ่มทุกจุดใช้คำว่า “ดูราคา” หรือ “ดูรายละเอียด” ไม่มี “สั่งซื้อ”, cart, checkout หรือ payment copy
3. Public API whitelist fields และไม่คืน `source_price`, admin metadata, password หรือ session
4. Crawler เริ่มจาก `https://www.overtopup.com/th`, ค้นพบ category/game/product แบบ dynamic, จำกัด request, parse metadata/DOM fallback, ตรวจราคา/รูป, upsert ด้วย unique key และคงข้อมูลเดิมเมื่อ source ล่ม
5. Pricing engine ใช้ `selling_price = source_price × (1 + margin/100)` โดย default margin 20%, rounding/currency/timezone อยู่ใน settings และบันทึก price history
6. Admin routes `/admin`, `/admin/games`, `/admin/products`, `/admin/pricing`, `/admin/sync`, `/admin/price-history`, `/admin/settings`, `/admin/account` ต้องใช้ `requireAdmin`; Admin เห็นต้นทุนได้เฉพาะฝั่ง protected
7. Initial admin password มาจาก `INITIAL_ADMIN_PASSWORD`, hash ด้วย scrypt, session token hash ใน DB, HttpOnly/Secure/SameSite=None สำหรับ Preview HTTPS, CSRF และบังคับเปลี่ยน password ครั้งแรก
8. `/api/scheduled/sync` เตรียมไว้สำหรับ schedule หลัง publish และ `/api/health` ตรวจ DB readiness

## Delivery constraints

ไม่ใช้ข้อมูลเกม/ราคาปลอมใน catalog; ต้องตรวจ `pnpm check`, production build, health, route manifest, public source-price isolation และ Admin protection ก่อน checkpoint การ publish เป็นขั้นตอนแยกต่างหาก
