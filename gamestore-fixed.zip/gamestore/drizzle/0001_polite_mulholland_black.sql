CREATE TABLE `admins` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(80) NOT NULL,
	`email` varchar(320),
	`password_hash` varchar(128) NOT NULL,
	`password_salt` varchar(64) NOT NULL,
	`must_change_password` int NOT NULL DEFAULT 1,
	`is_active` int NOT NULL DEFAULT 1,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`last_login_at` timestamp,
	CONSTRAINT `admins_id` PRIMARY KEY(`id`),
	CONSTRAINT `admins_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
CREATE TABLE `categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(120) NOT NULL,
	`name` varchar(160) NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `categories_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `games` (
	`id` int AUTO_INCREMENT NOT NULL,
	`slug` varchar(255) NOT NULL,
	`name` varchar(255) NOT NULL,
	`category` varchar(120) NOT NULL,
	`description` text,
	`image_url` text,
	`banner_url` text,
	`source_url` text NOT NULL,
	`status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
	`last_updated` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `games_id` PRIMARY KEY(`id`),
	CONSTRAINT `games_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `login_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`username` varchar(160) NOT NULL,
	`ip_address` varchar(80),
	`success` int NOT NULL DEFAULT 0,
	`attempted_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `login_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `order_inputs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`order_id` int NOT NULL,
	`order_item_id` int NOT NULL,
	`field_key` varchar(80) NOT NULL,
	`field_value` text NOT NULL,
	CONSTRAINT `order_inputs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `order_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`order_id` int NOT NULL,
	`product_id` int NOT NULL,
	`game_name` varchar(255) NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`product_type` varchar(40) NOT NULL,
	`quantity` int NOT NULL,
	`unit_price` decimal(12,2) NOT NULL,
	`total_price` decimal(12,2) NOT NULL,
	CONSTRAINT `order_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`order_number` varchar(40) NOT NULL,
	`customer_name` varchar(160),
	`customer_email` varchar(320),
	`customer_phone` varchar(40),
	`status` varchar(32) NOT NULL DEFAULT 'PENDING_PAYMENT',
	`payment_status` varchar(32) NOT NULL DEFAULT 'UNPAID',
	`total_amount` decimal(12,2) NOT NULL,
	`currency` varchar(8) NOT NULL DEFAULT 'THB',
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_order_number_unique` UNIQUE(`order_number`)
);
--> statement-breakpoint
CREATE TABLE `price_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_id` int NOT NULL,
	`old_source_price` decimal(12,2),
	`new_source_price` decimal(12,2) NOT NULL,
	`old_selling_price` decimal(12,2),
	`new_selling_price` decimal(12,2) NOT NULL,
	`margin_percent` decimal(6,2) NOT NULL,
	`changed_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `price_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `product_images` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_id` int NOT NULL,
	`url` text NOT NULL,
	`image_type` varchar(40) NOT NULL DEFAULT 'product',
	`status` varchar(32) NOT NULL DEFAULT 'VALID',
	`error_message` text,
	`source_url` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `product_images_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`game_id` int NOT NULL,
	`category` varchar(120) NOT NULL,
	`product_key` varchar(255) NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`source_price` decimal(12,2) NOT NULL,
	`selling_price` decimal(12,2) NOT NULL,
	`margin_percent` decimal(6,2) NOT NULL,
	`product_type` varchar(40) NOT NULL DEFAULT 'OTHER',
	`image_url` text,
	`thumbnail_url` text,
	`source_url` text NOT NULL,
	`status` varchar(32) NOT NULL DEFAULT 'ACTIVE',
	`last_sync_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `settings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`setting_key` varchar(120) NOT NULL,
	`setting_value` text NOT NULL,
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `settings_id` PRIMARY KEY(`id`),
	CONSTRAINT `settings_setting_key_unique` UNIQUE(`setting_key`)
);
--> statement-breakpoint
CREATE TABLE `sync_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`status` varchar(24) NOT NULL,
	`progress` varchar(255),
	`started_at` timestamp NOT NULL DEFAULT (now()),
	`completed_at` timestamp,
	`games_found` int NOT NULL DEFAULT 0,
	`products_found` int NOT NULL DEFAULT 0,
	`new_products` int NOT NULL DEFAULT 0,
	`updated_products` int NOT NULL DEFAULT 0,
	`price_changes` int NOT NULL DEFAULT 0,
	`images_updated` int NOT NULL DEFAULT 0,
	`missing_products` int NOT NULL DEFAULT 0,
	`error_message` text,
	CONSTRAINT `sync_logs_id` PRIMARY KEY(`id`)
);
