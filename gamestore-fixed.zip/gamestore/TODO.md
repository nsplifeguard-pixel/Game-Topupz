# GAME TOPUP PRICE CHECKER — Acceptance Criteria

## Brand และ public experience
- ใช้โลโก้ Game Topup ที่ผู้ใช้แนบเป็น Brand Identity หลักใน header, hero, footer, favicon, loading, mobile navigation, admin login และ error/fallback โดยไม่สร้างโลโก้ใหม่ ไม่เปลี่ยนชื่อ ไม่บิดสัดส่วน และไม่ทำให้ภาพแตก
- ธีมเป็น Dark Gaming × Premium × Futuristic × Neon Blue พร้อม responsive desktop/tablet/mobile และ visual identity เดียวกันทุกหน้า
- หน้า Home สื่อชัดว่าเป็นเว็บเช็คราคา: `เช็คราคาเกมและสินค้าดิจิทัล`, `ดูราคาอัปเดตจากต้นทาง`, และระบุว่าเว็บนี้ไม่มีการเติมเกม ไม่มีการสั่งซื้อ และไม่มีการชำระเงิน

## Catalog และ pricing
- ใช้ managed MySQL ผ่าน Drizzle สำหรับ games, products, images, price_history, sync_logs, settings, admins และ sessions; มี indexes/unique key สำหรับ game/product source data
- เก็บ `source_price` ฝั่ง server/Admin เท่านั้น; public API และ public UI แสดงเฉพาะชื่อสินค้า รายละเอียด selling price รูป เกม ประเภท และสถานะ
- default `margin_percent=20`; คำนวณ `selling_price = source_price * (1 + margin/100)` ตาม rounding/currency/timezone ใน settings และบันทึก price history เมื่อราคาเปลี่ยน
- สินค้าที่หายจาก source หรือไม่มีราคาให้เป็น `OUT_OF_STOCK` ไม่ลบ และไม่แสดงใน public active catalog

## Crawler และ Sync
- crawler เริ่มจาก `https://www.overtopup.com/th`, ค้นพบ category/game/product จาก internal links แบบ dynamic, normalize/deduplicate URL และรองรับเกมใหม่ในอนาคต
- fetch client มี user-agent, timeout, bounded retry/concurrency/rate limit/max response size และไม่ bypass protection/robots/Terms
- parser เก็บชื่อเกม slug category description source price product type source URL รูปเกม/product/banner/thumbnail พร้อม fallback และตรวจ image/price
- sync upsert ด้วย unique key, คำนวณ selling price ฝั่ง server, บันทึก history/log/counts, ป้องกัน concurrent run และเมื่อ source ล่มคงข้อมูลเดิมพร้อมข้อความ `ไม่สามารถ Sync ข้อมูลจากต้นทางได้ — กำลังใช้ข้อมูลล่าสุด`
- มี `POST /api/scheduled/sync` แบบ idempotent สำหรับเตรียมตั้งเวลา 6 ชั่วโมง/12 ชั่วโมง/03:00 Asia/Bangkok หลัง publish

## Public routes
- มีเฉพาะ `/`, `/games`, `/games/:slug` สำหรับ Home, catalog search/filter และรายละเอียดเกม/สินค้า
- Product Card และ price modal มีปุ่ม `ดูราคา`/`ดูรายละเอียด` เท่านั้น ไม่มี `สั่งซื้อ`, `เพิ่มลงตะกร้า`, `Checkout`, `ชำระเงิน`, `Order` หรือช่อง UID/Password สำหรับการเติม
- ไม่มี route หรือเมนู cart/checkout และไม่มี public order API
- มี pagination/limit, instant search, category filter, sort ราคา, game/product cards, loading/empty/error state และ responsive 2 cards ต่อแถวบนมือถือ

## Admin routes
- `/admin/login`, `/admin`, `/admin/games`, `/admin/products`, `/admin/pricing`, `/admin/sync`, `/admin/price-history`, `/admin/settings`, `/admin/account` เชื่อม DB จริง ไม่ใช่ mockup
- Dashboard แสดง games/products/active/out-of-stock/categories/last sync/new/updated/price changes
- Products management แสดง source price เฉพาะ Admin, selling price, margin, status, source/image state และ last update
- Pricing รองรับ presets 15/20/25/30, custom margin, rounding/currency และคำนวณราคาขายใหม่ทั้งหมดพร้อม price history
- Sync page มี `SYNC NOW`, progress, logs, errors และ latest-data fallback
- ไม่มี Admin orders/customers workflow เพราะระบบไม่รับคำสั่งซื้อหรือชำระเงิน

## Security และ validation
- initial admin username `admin`; password มาจาก `INITIAL_ADMIN_PASSWORD` secret เท่านั้น, hash ด้วย scrypt, first login บังคับเปลี่ยน password
- session token hash ใน DB, HttpOnly/SameSite=None/Secure cookie สำหรับ Preview HTTPS, expiry, logout, logout-all, CSRF และ rate limit
- ทุก `/api/admin/*` ใช้ `requireAdmin`; public responses ไม่คืน source_price หรือ secret
- `/api/health` ตอบ 2xx และตรวจ DB; `client/public/manus-routes.json` ประกาศเฉพาะ routes จริงและตอบ HTTP 200 JSON
- `pnpm check`, production build, public isolation, Admin protection และ Sync สำเร็จต้องผ่านก่อน checkpoint
