# Over Topup source notes

ตรวจสอบเมื่อ 2026-10-04 จาก `https://www.overtopup.com/th` ด้วย user-agent ของ crawler:

- หน้า source ตอบ HTTP 200 และมีหมวดหมู่ internal links เช่น `/th/game-topup`, `/th/game-topup-idpass`, `/th/card` และ `/th/topup`
- หน้าเกมมี h1/OG metadata, รูปเกมใต้ `/assets/image/game/` และรูปสินค้าใต้ `/assets/image/game/product/`
- ราคาหน้าสาธารณะใช้รูปแบบเงินบาท `฿` และชื่อสินค้าอยู่ใน alt/text ของ product cards
- Crawler ของ Game Topup จึงค้นพบ category/game URLs แบบ dynamic, parse h1/OG/image/product price และ normalize key ก่อน upsert
- การใช้งานเชิงพาณิชย์ควรตรวจสอบ Terms, robots และสิทธิ์รูปภาพ/ข้อมูลกับต้นทางก่อน publish
